package klab.serialization;
public class Message {
    public Message() {
        
    }
}