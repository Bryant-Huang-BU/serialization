package metanode.serialization;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;

public class Message {
    private final int version;
    private final MessageType type;
    private final ErrorType error;
    private int sessionID;
    private int count = 0;
    private final List<InetSocketAddress> addresses;

    public Message(MessageType type, ErrorType error, int sessionID) 
    throws IllegalArgumentException {
        if (type == null) {
            throw new IllegalArgumentException("Message type cannot be null.");
        }
        if (error == null) {
            throw new IllegalArgumentException("Error type cannot be null.");
        }
        this.version = 0;
        this.type = type;
        this.error = error;
        this.sessionID = sessionID;
        this.count = 0;
        this.addresses = null;
    }

    public Message(byte[] buf) throws IOException, IllegalArgumentException {
        if (buf == null) {
            throw new IllegalArgumentException("Buffer cannot be null.");
        }
        if (buf.length < 6) {
            throw new IllegalArgumentException("Buffer length must be at least 6.");
        }
        //version is 4 bits
        version = (buf[0] & 0xF0) >> 4;
        if (version != 4) {
            throw new IOException("Invalid version: " + version);
        }
        //type is 4 bits, unsigned
        int typeint = (buf[0] & 0x0F);
        if (typeint < 0 || typeint >= MessageType.values().length) {
            throw new IOException("Invalid message type: " + typeint);
        }   
        type = MessageType.getByCode(typeint);
        //error is an unsigned integer
        int errorint = (int) (buf[1] & 0xFF);
        if (errorint < 0 || errorint >= ErrorType.values().length) {
            throw new IOException("Invalid error type: " + errorint);
        }
        error = ErrorType.getByCode(errorint);
        if (type.getCode() > 1 && buf.length > 5) {
            throw new IOException("There " + 
            "should be no addresses for this message type.");
        }

        //data is a byte array of addresses and ports
        int countdata = 0;
        int[] ip = new int[5];
        addresses = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            for (int j = 0; j < 5; j++) {
                //System.out.println(buf4[i]);
                ip[j] = buf[2 + 5 * i + j] & 0xFF;
            }
            ip[4] = buf[2 + 5 * i + 4] & 0xFF;
            Inet4Address addr = (Inet4Address) Inet4Address.getByName(
            ip[0] + "." + ip[1] + "." + ip[2] + "." + ip[3]);
            addresses.add(new InetSocketAddress(addr, ip[4]));
            countdata++;
        }
        if (countdata != count) {
            throw new IOException("The number of addresses " + 
            "in the message does not match the count.");
        }
        if ((countdata * 5) + 5 != buf.length) {
            throw new IOException("The number of addresses " + 
            "in the message does not match the buffer length.");
        }
        
    }

    public byte[] encode() {
        byte[] buf = new byte[6];
        buf[0] = (byte) type.getCode();
        buf[1] = (byte) error.getCode();
        buf[2] = (byte) (sessionID >> 24);
        buf[3] = (byte) (sessionID >> 16);
        buf[4] = (byte) (sessionID >> 8);
        buf[5] = (byte) sessionID;
        return buf;
    }

    public String toString() {
        return "Message[type=" + type + ", error=" + 
        error + ", sessionID=" + sessionID + "]";
    }

    public MessageType getType() {
        return type;
    }

    public ErrorType getError() {
        return error;
    }

    public int getSessionID() {
        return sessionID;
    }

    public Message setSessionID(int sessionID) throws IllegalArgumentException {
        if (sessionID < 0) {
            throw new IllegalArgumentException("Session ID must be non-negative.");
        }
        this.sessionID = sessionID;
        return this;
    }

    public List<InetSocketAddress> getAddresses() {
        return addresses;
    }

    public Message addAddress(InetSocketAddress newAddress)
    throws IllegalArgumentException {
        if (newAddress == null) {
            throw new IllegalArgumentException("Address cannot be null.");
        }
        addresses.add(newAddress);
        return this;
        
    }

    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + 
        ((addresses == null) ? 0 : addresses.hashCode());
        result = prime * result + 
        ((error == null) ? 0 : error.hashCode());
        result = prime * result + sessionID;
        result = prime * result + 
        ((type == null) ? 0 : type.hashCode());
        result = prime * result + version;
        return result;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Message other = (Message) obj;
        if (addresses == null) {
            if (other.addresses != null) {
                return false;
            }
        } else if (!addresses.equals(other.addresses)) {
            return false;
        }
        if (error != other.error) {
            return false;
        }
        if (sessionID != other.sessionID) {
            return false;
        }
        if (type != other.type) {
            return false;
        }
        if (version != other.version) {
            return false;
        }
        return true;
    }
}
