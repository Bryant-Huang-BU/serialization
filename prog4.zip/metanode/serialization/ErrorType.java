package metanode.serialization;

public enum ErrorType {
    None, System, IncorrectPacket;

    public int getCode() {
        switch (this) {
            case None:
                return 0;
            case System:
                return 1;
            case IncorrectPacket:
                return 2;
            default:
                throw new IllegalArgumentException(
                "Invalid error type: " + this);
        }
    }

    public static ErrorType getByCode(int code) {
        switch (code) {
            case 0:
                return None;
            case 1:
                return System;
            case 2:
                return IncorrectPacket;
            default:
                throw new IllegalArgumentException(
                "Invalid error type code: " + code);
        }
    }
}
