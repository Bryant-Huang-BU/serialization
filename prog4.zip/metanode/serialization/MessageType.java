package metanode.serialization;
/**
 * Represents the type of a message in the system.
 */
public enum MessageType {
    RequestNodes,
    RequestMetaNodes,
    AnswerRequest,
    NodeAdditions,
    MetaNodeAdditions,
    NodeDeletions,
    MetaNodeDeletions,
    ClearCache;

    /**
     * Retrieves the InnerMessageType enum value 
     * based on the given command string.
     *
     * @param s The command string
     * representing the message type.
     * @return The InnerMessageType enum 
     * value corresponding to the command string.
     * @throws IllegalArgumentException If 
     * the command string is invalid.
     */
    public static MessageType getByCmd(String s) {
        switch (s) {
            case "RequestNodes":
                return RequestNodes;
            case "RequestMetaNodes":
                return RequestMetaNodes;
            case "AnswerRequest":
                return AnswerRequest;
            case "NodeAdditions":
                return NodeAdditions;
            case "MetaNodeAdditions":
                return MetaNodeAdditions;
            case "NodeDeletions":
                return NodeDeletions;
            case "MetaNodeDeletions":
                return MetaNodeDeletions;
            case "ClearCache":
                return ClearCache;
            default:
                throw new IllegalArgumentException(
                        "Invalid message type: " + s);
        }
    }
    /**
     * Returns the MessageType corresponding to the given code.
     *
     * @param code the code representing the MessageType
     * @return the MessageType corresponding to the code
     * @throws IllegalArgumentException if the code is invalid
     */
    public static MessageType getByCode(int code) {
        switch (code) {
            case 0:
                return RequestNodes;
            case 1:
                return RequestMetaNodes;
            case 2:
                return AnswerRequest;
            case 3:
                return NodeAdditions;
            case 4:
                return MetaNodeAdditions;
            case 5:
                return NodeDeletions;
            case 6:
                return MetaNodeDeletions;
            case 7:
                return ClearCache;
            default:
                throw new IllegalArgumentException(
                "Invalid message type code: " + code);
        }
    }
    
    /**
     * Returns the code associated with the message type.
     *
     * @return the code associated with the message type
     * @throws IllegalArgumentException if the message type is invalid
     */
    public int getCode() {
        switch (this) {
            case RequestNodes:
                return 0;
            case RequestMetaNodes:
                return 1;
            case AnswerRequest:
                return 2;
            case NodeAdditions:
                return 3;
            case MetaNodeAdditions:
                return 4;
            case NodeDeletions:
                return 5;
            case MetaNodeDeletions:
                return 6;
            case ClearCache:
                return 7;
            default:
                throw new IllegalArgumentException(
                "Invalid message type: " + this);
        }
    }

    /**
     * Returns the command associated with the message type.
     *
     * @return the command as a string
     * @throws IllegalArgumentException if the message type is invalid
     */
    public String getCmd() {
        switch (this) {
            case RequestNodes:
                return "RequestNodes";
            case RequestMetaNodes:
                return "RequestMetaNodes";
            case AnswerRequest:
                return "AnswerRequest";
            case NodeAdditions:
                return "NodeAdditions";
            case MetaNodeAdditions:
                return "MetaNodeAdditions";
            case NodeDeletions:
                return "NodeDeletions";
            case MetaNodeDeletions:
                return "MetaNodeDeletions";
            case ClearCache:
                return "ClearCache";
            default:
                throw new IllegalArgumentException(
                "Invalid message type: " + this);
        }
    }
}
